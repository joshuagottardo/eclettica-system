const path = window.location.pathname;

// Permetti anche la root (/) come homepage!
if (path.endsWith('/') || path.endsWith('index.html')) {
  import('./pages/home.js');
} else if (path.endsWith('inserimento.html')) {
  import('./pages/inserimento.js');
} else if (path.endsWith('ricerca.html')) {
  import('./pages/ricerca.js');
}

document.addEventListener('DOMContentLoaded', () => {
  const btn = document.getElementById('open-inserimento');
  if (btn) {
    btn.addEventListener('click', () => {
      window.location.href = 'inserimento.html';
    });
  }
});