const baseUrl = 'https://trentin-nas.synology.me/images';
const imgUrl = `${baseUrl}/${foto_principale}`;
console.log(imgUrl); // This will log the full URL to the console


// -> "https://trentin-nas.synology.me/images/foto1.jpg"
