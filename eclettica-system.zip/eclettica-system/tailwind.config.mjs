/** @type {import('tailwindcss').Config} */

export default {
  content: [
    "./renderer/**/*.{html,js}"
  ],
    theme: {
      extend: {
        colors: {
          custom: {
            100: '#121212',
            200: '#1e1e1e',
            300: '#232323',
            400: '#252525',
            500: '#272727',
            600: '#2c2c2c',
            700: '#2e2e2e',
            800: '#333333',
            900: '#363636',
            950: '#383838',
          },
        },
      },
    },
  plugins: [],
}
